var searchData=
[
  ['othello_2ecc',['othello.cc',['../othello_8cc.html',1,'']]],
  ['othello_2eh',['othello.h',['../othello_8h.html',1,'']]]
];
