var searchData=
[
  ['othello',['Othello',['../classmain__savitch__14_1_1Othello.html',1,'main_savitch_14']]]
];
