Matthew David Brooks
I love Ghost in the Shell.
It is the best movie of all time.
Here is the third line.
