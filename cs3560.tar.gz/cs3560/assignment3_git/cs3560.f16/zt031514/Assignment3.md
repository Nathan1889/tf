Zachary Tumbleson

This is homework assignment 3 for CS3560.
To be honest, I haven't had much experience with Linux.
It seems rather intuitive once you get used to it.
