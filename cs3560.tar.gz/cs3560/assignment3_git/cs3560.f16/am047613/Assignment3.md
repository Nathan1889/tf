# Aaron McQuade 
this is the readme for the class repo
cs  3650
9/7/2016

